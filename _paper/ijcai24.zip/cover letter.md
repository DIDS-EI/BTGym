Cover Letter Responding to the Previous Reviews

Major Concerns and Changes:

1. Concerns: the two simulation environment (RobotWaiter and VirtualHome) has limitations in the real world, which is not a good way to evaluate the performance of the model.
Changes:
- Add a new section to show the experimental results.
- Add a new section to show the future work.
2. Concerns: lack of details on platform integration and usability.
Changes:
- Add a new section to show the platform integration and usability.
3. Concerns: insufficient details on platform integration and usability.
Changes:
- Add a new section to show the platform integration and usability.

Minor changes:

1. Add a new section to show the future work.
2. Add a new section to show the experimental results.
3. Add a new section to show the future work.
